# J I N N I

![alt text](tn.jpg)

## Development setup

Use Python 3.11 on Windows, then install the checked-in environment and quality tools:

```powershell
python -m pip install -r requirements-lock.txt -r requirements-dev.txt
pre-commit install
```

Install Jinni as a command with `python -m pip install -e .`. Copy `settings.example.toml` to `settings.toml` to override defaults; `JINNI_SETTINGS` can point to another TOML file. Unknown keys and values with the wrong type are rejected at startup. MCP server allowlists can still be managed in `mcp_servers.json`.

Run `python -m pytest`, `ruff check .`, and `pyright` before opening a pull request. CI runs the same checks on pushes and pull requests.

## Charts and data

`make_chart` reads CSV files and `.xlsx` workbooks from the workspace. Excel input uses the first worksheet; legacy `.xls` files are not supported. Tables can contain up to 50 data rows.

Supported chart kinds are `bar`, `stacked`, `line`, `pie`, and `donut`. Use `secondary_y_column` with a line chart when a series needs its own scale. Narrow single-series bars use compact value labels. The chart palette is based on the [Okabe–Ito Color Universal Design palette](https://jfly.uni-koeln.de/color/), with different dash patterns for line series so color is not the only cue.

Chart export commands save files beside the HTML chart:

- `/png [chart] [light|dark] [WIDTHxHEIGHT]`
- `/svg [chart]`
- `/pdf [chart]`
- `/export-all [png|svg|pdf]` (omit the format to export every chart to all three formats)

`fetch_table(url, table_index)` saves a public HTML table as a CSV and records the source URL, fetch time, and content hash in a provenance sidecar. Charts made from that CSV retain the source and date.

To bridge data from MCP, configure an allowlisted server tool that returns JSON with `columns` and `rows`, then use `/mcp-table <server> <tool> [JSON arguments]`. The repository includes a local sales fixture at `tests/fixtures/chart_data_server.py`; configure it in `mcp_servers.json` to try `/mcp-table fixture get_table {"dataset":"sales"}`. The file has a top-level `servers` list; each entry can set `name`, `command`, `args`, `env`, `tools`, `remember`, `call_timeout`, and `mode`. If the file is missing, Jinni uses the built-in settings; an invalid file is reported and ignored.

MCP tool calls are checked against each server's advertised input schema before they are sent. Tools also must be explicitly allowlisted in `mcp_servers.json` or the built-in settings.

Jinni only fetches URLs that the user supplied or that appeared in a web-search result during the session. The existing per-domain approval still applies.

## Memory maintenance

During the exit review, Jinni flags facts that look similar to saved facts so you can decide whether to keep both or skip the new one. It also offers old facts for deletion; keeping one snoozes that prompt for another year. Use `/prune DAYS` to review session notes older than that many days; Jinni shows a preview and asks before deleting. Saved facts are not pruned automatically.

Use `/memory facts`, `/memory events`, or `/memory search TEXT` to filter saved memories. Each item shows its source session; memory facts added to the system prompt are capped at 2,400 characters.

## CLI shortcuts

Use `/help` for the command list, `/config` to inspect non-sensitive effective settings, `/stats` for session usage totals, `/save [NAME]` and `/load NAME` for bounded transcripts in `workspace/transcripts/`, and `/undo` to remove the latest chat turn from conversation history. `/undo` does not reverse file or other tool side effects.

Press the up arrow at the interactive prompt to recall earlier input.

During a chat, Jinni can ask a clarifying question and keep a SQLite-backed task list with `task_list` actions `list`, `due`, `add`, `done`, `remove`, and `clear`; added tasks can have an ISO due date, `/tasks` displays the list, and overdue tasks appear at startup. Clearing the list asks for confirmation. At the configured step limit, Jinni asks before continuing another block of tool calls.

## Project inspection tools

The read-only coding tools include ranged `read_file`, `search_files`, `find_files`, `code_outline`, and `project_tree`. Searches skip common generated folders, reject unsafe regex patterns, and cap their scan and output sizes.

Use `check_python(path, checker)` for a bounded syntax check, Ruff lint, or Pyright type check. Ruff and Pyright are optional local tools; checks time out, cap their output, and never apply fixes.

## Read-only MCP server

Run `python mcp_server.py` from the project directory as an MCP stdio server. It exposes only `list_files`, `read_file`, and `recall`; file access stays inside the workspace. It has no write, web, or delete tools.
